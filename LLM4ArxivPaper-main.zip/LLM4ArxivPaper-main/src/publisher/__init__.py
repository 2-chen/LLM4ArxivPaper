"""Output publishing helpers (static site, email, etc.)."""
