"""Data acquisition utilities (arXiv, ar5iv, etc.)."""
